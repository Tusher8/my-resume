$.stellar();




$(document).ready(function(){


    AOS.init({
        duration: 650,
      });

      $(window).on('scroll', function () {
        var scroll = $(window).scrollTop();
        if (scroll < 400) {
        $("header").removeClass("sticky");
        } else {
        $("header").addClass("sticky");
        }
    });


    /*------------------
       Slick Active Code
    --------------------*/
        $('.slider_for').slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            speed: 500,
            arrows: false,
            fade: true,
            asNavFor: '.slider_nav'
        });
        $('.slider_nav').slick({
            slidesToShow: 3,
            slidesToScroll: 1,
            speed: 500,
            asNavFor: '.slider_for',
            dots: true,
            centerMode: true,
            focusOnSelect: true,
            slide: 'div',
            autoplay: true,
            centerMode: true,
            centerPadding: '30px',
            mobileFirst: true,
            prevArrow: '<i class="fa fa-angle-left"></i>',
            nextArrow: '<i class="fa fa-angle-right"></i>'
        });



        /*------------------
       Mobile menu Active Code
    --------------------*/
    $('.menu-btn').click(function(){
        $('.slidebar').toggleClass("show");
        $(".offcanvas__menu__overlay").addClass("overlay-offcanvas");
    });
    
  const menuBtn = document.querySelector('.menu-btn');
  let menuOpen =false;
  menuBtn.addEventListener('click', () => {
      if(!menuOpen) {
          menuBtn.classList.add('open');
          menuOpen = true;
      } else {
          menuBtn.classList.remove('open');
          menuOpen = false;
      }
  });


  
        /*------------------
       Mobile menu Active Code
    --------------------*/
    $('.mobile-menu-wrap').click(function(){
        $('.offcanvas-menu-wrapper').toggleClass("show");
        $(".offcanvas-menu-overlay").toggleClass("show");
        $(".logo").toggleClass("ammou");
    });




        /*------------------
       Scroll Up Active Code
    --------------------*/
  $('.js-gotop').on('click', function(){

    $('html, body').animate({
        scrollTop: $(window).height()-$(document).height()
    }, 800);
    
    return false;
});

$(window).scroll(function(){

    var $win = $(window);
    if ($win.scrollTop() > 200) {
        $('.js-top').addClass('active');
    } else {
        $('.js-top').removeClass('active');
    }

});

});